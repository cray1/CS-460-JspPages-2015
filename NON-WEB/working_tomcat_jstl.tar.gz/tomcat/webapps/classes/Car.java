/**
 * 
 */


/**
 **+----------------------------------------------------------------------
 * @Class:  
 *
 * @Author:
 *
 * @Purpose:
 * 
 * @Inherits From:
 * 
 * @Interfaces: 
 * 
 * @Constants: 
 * 
 * @Constructors:
 * 
 * @Static Class Methods:
 * 
 * @Inst. Methods: 
 *  
 *
 **+----------------------------------------------------------------------
 */
public class Car {

	public int carId;
	public String description;
	public String registrationNumber;
	
	/**
	 * 
	 * @Method:  Car
	 *
	 * @Purpose:
	 *
	 * @Pre-condition:
	 *
	 * @Post-condition: 
	 * 
	 * @Params: @param carId
	 * @Params: @param description
	 * @Params: @param registrationNumber 
	 * 
	 */
	public Car(int carId, String description, String registrationNumber) {
		this.carId = carId;
		this.description = description;
		this.registrationNumber = registrationNumber;
	}

	
	 
}
