/**
 * 
 */


/**
 **+----------------------------------------------------------------------
 * @Class:  
 *
 * @Author:
 *
 * @Purpose:
 * 
 * @Inherits From:
 * 
 * @Interfaces: 
 * 
 * @Constants: 
 * 
 * @Constructors:
 * 
 * @Static Class Methods:
 * 
 * @Inst. Methods: 
 *  
 *
 **+----------------------------------------------------------------------
 */
public class JobTitle {

	public int jobTitleId;
	public String title;
	
	/**
	 * 
	 * 
	 * @Method:  JobTitle
	 *
	 * @Purpose:
	 *
	 * @Pre-condition:
	 *
	 * @Post-condition: 
	 * 
	 * @Params: @param jobTitleId
	 * @Params: @param title 
	 *
	 */
	public JobTitle(int jobTitleId, String title){
		this.jobTitleId = jobTitleId;
		this.title = title;
	}
}
